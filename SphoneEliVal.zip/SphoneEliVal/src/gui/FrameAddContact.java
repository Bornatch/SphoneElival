package gui;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.ParseException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import BDContacts.Contacts;

/**
 * Frame d'ajout et de modification des contacts *
 * 
 * 
 *
 */
@SuppressWarnings("serial")
public class FrameAddContact extends FramePrincipale {

	// cr�ation du panel
	private JPanel panelCenter = new JPanel();

	// les Labels d'en t�te
	private JLabel nomTitreLabel = new JLabel("Noms");
	private JLabel prenomLabel = new JLabel("Pr�nom");
	private JLabel nomLabel = new JLabel("Nom");
	private JLabel numTitrelLabel = new JLabel("Num�ros");
	private JLabel numNatelLabel = new JLabel("Priv�");
	private JLabel numProLabel = new JLabel("Professionnel");
	private JLabel diversLabel = new JLabel("Autres");
	private JLabel mailLabel = new JLabel("E-mail");

	// Champs d'insertion du texte ( sauf num�ros, d�clar�s dans la classe)
	private JTextField prenomField = new JTextField("pr�nom");
	private JTextField nomField = new JTextField("nom");
	private JFormattedTextField numNatelField;
	JFormattedTextField numProField;
	private JTextField mailField = new JTextField("mail");

	// Bouton d'image de profil
	static JButton profilPic = new JButton(new ImageIcon("./icon/user.png"));

	// Les boutons : sauvegarde et retour � Contacts
	private JButton cancel = new JButton(new ImageIcon("./icon/cancel.png"));
	private JButton save = new JButton(new ImageIcon("./icon/save.png"));

	// D�claration des polices
	Font titre = new Font("helvetica", Font.BOLD, 25);

	Font ssTitre = new Font("helvetica", Font.BOLD, 20);
	Font texte = new Font("helvetica", Font.BOLD, 14);

	public FrameAddContact() {

		// Ajout du panel dans ma frame
		this.add(panelCenter, BorderLayout.CENTER);
		panelCenter.setBackground(super.getBackground());
		panelCenter.setLayout(null);
		panelCenter.setBounds(21, 105, 378, 609);

		// Champs d'insertion des num�ros format�s
		MaskFormatter tel;
		try {
			tel = new MaskFormatter("### ### ## ##");
			numNatelField = new JFormattedTextField(tel);
			numProField = new JFormattedTextField(tel);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		// Ajout de l'icon du profil
		panelCenter.add(profilPic);
		profilPic.setContentAreaFilled(false);
		profilPic.setBorderPainted(false);
		profilPic.setBounds(21, 5, 150, 150);

		profilPic.addActionListener(new TraitementProfilPic());

		// Ajout des labels
		panelCenter.add(nomTitreLabel);
		nomTitreLabel.setFont(ssTitre);
		nomTitreLabel.setBounds(20, 150, 100, 40);

		panelCenter.add(prenomLabel);
		prenomLabel.setFont(texte);
		prenomLabel.setBounds(20, 190, 100, 30);

		panelCenter.add(nomLabel);
		nomLabel.setFont(texte);
		nomLabel.setBounds(20, 220, 100, 50);

		panelCenter.add(numTitrelLabel);
		numTitrelLabel.setFont(ssTitre);
		numTitrelLabel.setBounds(20, 270, 100, 40);

		panelCenter.add(numNatelLabel);
		numNatelLabel.setFont(texte);
		numNatelLabel.setBounds(20, 310, 100, 30);

		panelCenter.add(numProLabel);
		numProLabel.setFont(texte);
		numProLabel.setBounds(20, 340, 100, 50);

		panelCenter.add(diversLabel);
		diversLabel.setFont(ssTitre);
		diversLabel.setBounds(20, 390, 100, 40);

		panelCenter.add(mailLabel);
		mailLabel.setFont(texte);
		mailLabel.setBounds(20, 430, 100, 30);

		// Ajout des textField
		panelCenter.add(prenomField);
		prenomField.setFont(texte);
		prenomField.setBounds(150, 190, 200, 30);

		panelCenter.add(nomField);
		nomField.setFont(texte);
		nomField.setBounds(150, 230, 200, 30);

		panelCenter.add(numNatelField);
		numNatelField.setFont(texte);
		numNatelField.setBounds(150, 310, 200, 30);

		panelCenter.add(numProField);
		numProField.setFont(texte);
		numProField.setBounds(150, 350, 200, 30);

		panelCenter.add(mailField);
		mailField.setFont(texte);
		mailField.setBounds(150, 430, 200, 30);

		// Ajout des boutons
		panelCenter.add(cancel);
		cancel.setBounds(panelCenter.getWidth() / 3 * 2, 500, panelCenter.getWidth() / 3, 70);
		cancel.setOpaque(true);
		cancel.setContentAreaFilled(false);
		cancel.setBorderPainted(false);

		cancel.addActionListener(new TraitementCancel());

		panelCenter.add(save);
		save.setBounds(0, 500, panelCenter.getWidth() / 3, 70);
		save.setOpaque(true);
		save.setContentAreaFilled(false);
		save.setBorderPainted(false);

		save.addActionListener(new TraitementSave());

	}

	public class TraitementProfilPic implements ActionListener {
		/**
		 * comportement du bouton de l'image du profil,
		 */
		public void actionPerformed(ActionEvent e) {

			@SuppressWarnings("unused")
			FrameGallerieProfilChooser gallerie = new FrameGallerieProfilChooser();
		}
	}

	public class TraitementCancel implements ActionListener {
		/**
		 * comportement du bouton retour (cancel),
		 */
		public void actionPerformed(ActionEvent e) {

			JFrame contacts;
			try {
				contacts = new FrameContacts();
				contacts.setVisible(true);
				profilPic.setIcon(new ImageIcon("./icon/user.png"));
			} catch (IOException e1) {
				e1.printStackTrace();
			} finally {
				dispose();
			}

		}
	}

	public class TraitementSave implements ActionListener {
		/**
		 * comportement du bouton save
		 */
		public void actionPerformed(ActionEvent e) {

			String nom = nomField.getText();
			String prenom = prenomField.getText();
			String numNatel = numNatelField.getText();
			String numPro = numProField.getText();
			String mail = mailField.getText();
			ImageIcon icon = (ImageIcon) profilPic.getIcon();
			profilPic.setIcon(new ImageIcon("./icon/user.png"));

			Contacts nouveau = new Contacts(prenom, nom, numNatel, numPro, mail, icon);
			Contacts.AddContact(nouveau);

			JFrame contacts;
			try {
				contacts = new FrameContacts();
				contacts.setVisible(true);
			} catch (IOException e1) {
				e1.printStackTrace();
			} finally {
				dispose();
			}

		}
	}

}
